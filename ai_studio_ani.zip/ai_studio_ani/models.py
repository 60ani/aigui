import os
from huggingface_hub import InferenceClient
from decorators import log_call, validate_input


api_key = os.environ.get("HF_TOKEN", "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")
client = InferenceClient(api_key=api_key)
# Base model class (shows inheritance and encapsulation)
class BaseModel:
    def __init__(self, model_name):
        self._model_name = model_name  # encapsulated model name
        # Use environment variable or fallback to hardcoded token
        self._api_key = os.environ.get("HF_TOKEN", "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")
        self._client = InferenceClient(api_key=self._api_key)

    def get_info(self):
        return (
            f"Model Name: {self._model_name}\n"
            f"Description: Hugging Face model deployed via InferenceClient"
        )

    def _get_client(self):
        return self._client

# Object Detection Model (Image Analysis)
class ObjectDetectionModel(BaseModel):
    @log_call
    @validate_input
    def run(self, image_path):
        try:
            inference_client = self._get_client()
            # Object detection API expects the image file path or bytes
            result = inference_client.object_detection(image_path, model=self._model_name)
            
            # Format the detection results for display
            if isinstance(result, list) and len(result) > 0:
                formatted_output = "🔍 Detected Objects:\n\n"
                for idx, detection in enumerate(result, 1):
                    label = detection.get('label', 'Unknown')
                    score = detection.get('score', 0)
                    box = detection.get('box', {})
                    
                    formatted_output += f"{idx}. {label}\n"
                    formatted_output += f"   Confidence: {score:.2%}\n"
                    
                    if box:
                        formatted_output += f"   Location: x={box.get('xmin', 0):.0f}, y={box.get('ymin', 0):.0f}, "
                        formatted_output += f"width={box.get('xmax', 0) - box.get('xmin', 0):.0f}, "
                        formatted_output += f"height={box.get('ymax', 0) - box.get('ymin', 0):.0f}\n"
                    formatted_output += "\n"
                
                return formatted_output.strip()
            elif result:
                return str(result)
            else:
                return "No objects detected in the image."
        except Exception as e:
            raise Exception(f"Object detection failed: {str(e)}")

    def get_info(self):
        info = super().get_info()
        return (
            f"{info}\n"
            "Category: Object Detection\n"
            "Short Description: Detects and identifies objects in images with bounding boxes."
        )

# Text to Image Model
class TextToImageModel(BaseModel):
    @log_call
    @validate_input
    def run(self, input_text):
        try:
            inference_client = self._get_client()
            # Returns a PIL.Image object
            image = inference_client.text_to_image(input_text, model=self._model_name)
            
            # Verify it's an image-like object
            if not (hasattr(image, 'save') and hasattr(image, 'size')):
                raise Exception(f"Expected image object, got {type(image)}")
            
            return image
        except Exception as e:
            raise Exception(f"Image generation failed: {str(e)}")

    def get_info(self):
        info = super().get_info()
        return (
            f"{info}\n"
            "Category: Text to Image\n"
            "Short Description: Generates images from text using AI."
        )