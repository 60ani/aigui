# 🚀 Installation Guide - AI Studio

## Prerequisites

Before installing AI Studio, ensure you have:
- **Python 3.8 or higher** installed
- **pip** (Python package manager)
- **Internet connection** (for downloading dependencies and using AI models)
- **Git** (optional, for cloning repository)

---

## Step-by-Step Installation

### 1️⃣ Download/Clone the Project

**Option A: Using Git**
```bash
git clone <repository-url>
cd aigui
```

**Option B: Manual Download**
1. Download the project as ZIP
2. Extract to your desired location
3. Open terminal in the extracted folder

---

### 2️⃣ Verify Python Installation

```bash
# Check Python version
python --version

# Should show Python 3.8 or higher
# If not found, try:
python3 --version
```

**If Python is not installed:**
- Download from [python.org](https://www.python.org/downloads/)
- During installation, check "Add Python to PATH"

---

### 3️⃣ Create Virtual Environment (Recommended)

Creating a virtual environment isolates project dependencies.

**Windows (PowerShell):**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

**Windows (CMD):**
```cmd
python -m venv .venv
.venv\Scripts\activate.bat
```

**Linux/Mac:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

You should see `(.venv)` in your terminal prompt.

---

### 4️⃣ Install Dependencies

With virtual environment activated:

```bash
pip install -r requirements.txt
```

This will install:
- `transformers` - Hugging Face transformers library
- `huggingface_hub` - Hugging Face API client
- `torch` - PyTorch (AI framework)
- `Pillow` - Image processing library

**Note:** Installation may take 5-10 minutes depending on your internet speed.

---

### 5️⃣ Set Up Hugging Face Token (Optional but Recommended)

To avoid rate limits and access more models:

1. **Get a token:**
   - Go to [huggingface.co](https://huggingface.co/)
   - Create account (free)
   - Go to Settings → Access Tokens
   - Create new token
   - Copy the token

2. **Set environment variable:**

**Windows (PowerShell):**
```powershell
$env:HF_TOKEN="your_token_here"
```

**Windows (CMD):**
```cmd
set HF_TOKEN=your_token_here
```

**Linux/Mac:**
```bash
export HF_TOKEN=your_token_here
```

**Make it permanent:**

**Windows:**
- Search "Environment Variables" in Start Menu
- Click "Environment Variables"
- Under "User variables", click "New"
- Variable name: `HF_TOKEN`
- Variable value: Your token
- Click OK

**Linux/Mac:**
Add to `~/.bashrc` or `~/.zshrc`:
```bash
export HF_TOKEN="your_token_here"
```

---

### 6️⃣ Verify Installation

Run a quick test:

```bash
python -c "import tkinter; import PIL; import transformers; print('All imports successful!')"
```

If you see "All imports successful!", you're ready!

---

### 7️⃣ Launch the Application

```bash
python main.py
```

The AI Studio window should open!

---

## Troubleshooting

### Issue: "tkinter not found"

**Windows/Mac:**
- tkinter comes with Python, reinstall Python with "tcl/tk" option checked

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install python3-tk
```

**Linux (Fedora):**
```bash
sudo dnf install python3-tkinter
```

---

### Issue: "No module named 'PIL'"

```bash
pip install Pillow
```

---

### Issue: "torch installation fails"

**Option 1:** Install CPU-only version (smaller, faster):
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

**Option 2:** If you have NVIDIA GPU:
```bash
# Check CUDA version first
nvidia-smi

# Install with CUDA support (check PyTorch website for exact command)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

---

### Issue: "transformers installation is slow"

This is normal. The package is large (~500MB). Be patient.

If it times out, try:
```bash
pip install --timeout=1000 transformers
```

---

### Issue: "Permission denied" errors

**Windows:**
Run PowerShell/CMD as Administrator

**Linux/Mac:**
```bash
pip install --user -r requirements.txt
```

---

### Issue: "Application window doesn't appear"

1. Check terminal for error messages
2. Verify all imports work (step 6)
3. Try running with verbose output:
   ```bash
   python -v main.py
   ```

---

### Issue: "Model loading is very slow"

**First time is always slow** (downloading models):
- TrOCR model: ~1.5GB
- FLUX model: ~6GB
- Models are cached after first download

**Tips:**
- Ensure good internet connection
- Be patient on first run (10-20 minutes)
- Subsequent runs will be much faster

---

### Issue: "Rate limit exceeded"

Set up Hugging Face token (see Step 5)

---

## Platform-Specific Notes

### Windows
- Use PowerShell or CMD
- Backslashes in paths (handled automatically)
- Antivirus may slow first run
- Windows Defender might scan downloaded models

### macOS
- Use Terminal
- May need Xcode command line tools
- M1/M2 Macs: Works fine, might install ARM-specific packages

### Linux
- Usually smoothest installation
- May need python3-tk package
- Check Python version (some distros have old versions)

---

## Verification Checklist

Before using the application, verify:

- [ ] Python 3.8+ installed
- [ ] Virtual environment created and activated
- [ ] All dependencies installed successfully
- [ ] Test imports work (step 6)
- [ ] Application launches (step 7)
- [ ] HF token set (optional but recommended)

---

## Disk Space Requirements

Ensure you have enough free space:
- **Dependencies**: ~2-3 GB
- **Models (cached)**: ~8 GB
- **Project files**: ~1 MB
- **Total recommended**: 15 GB free space

---

## First Run Notes

### Expected Behavior
1. Application window opens immediately
2. Select a model (click card)
3. First model run triggers download (slow, one-time)
4. Progress shown in terminal
5. Subsequent runs are fast (models cached)

### Where Models Are Cached
**Windows:**
```
C:\Users\<username>\.cache\huggingface\
```

**Linux/Mac:**
```
~/.cache/huggingface/
```

You can safely delete this folder to reclaim space, but models will re-download on next use.

---

## Getting Help

If you encounter issues:

1. **Check error messages** in terminal
2. **Review troubleshooting section** above
3. **Verify Python version** (must be 3.8+)
4. **Try in a fresh virtual environment**
5. **Check internet connection**
6. **Consult course materials** or instructor

---

## Uninstallation

To remove the application:

1. **Deactivate virtual environment:**
   ```bash
   deactivate
   ```

2. **Delete project folder:**
   ```bash
   # From parent directory
   rm -rf aigui  # Linux/Mac
   # or
   rmdir /s aigui  # Windows CMD
   ```

3. **Clear model cache (optional):**
   ```bash
   # Windows
   rmdir /s C:\Users\<username>\.cache\huggingface

   # Linux/Mac
   rm -rf ~/.cache/huggingface
   ```

---

## Next Steps

After successful installation:

1. **Read the Quick Start Guide**: `QUICK_START.md`
2. **Try the application**: Run both models
3. **View OOP explanations**: Click "View OOP Concepts" button
4. **Explore the code**: Open source files in editor
5. **Read documentation**: Check `README.md`

---

## Update Instructions

To update the application:

```bash
# Pull latest changes (if using Git)
git pull

# Update dependencies
pip install --upgrade -r requirements.txt

# Run the updated application
python main.py
```

---

**You're all set! Enjoy using AI Studio! 🚀**

For usage instructions, see `QUICK_START.md`  
For technical details, see `README.md`  
For support, contact your instructor or TA

---

**Last Updated**: October 5, 2025  
**Version**: 2.0  
**Status**: Stable ✅
