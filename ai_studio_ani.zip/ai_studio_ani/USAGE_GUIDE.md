# 🚀 How to Use AI Studio - Step by Step

## Complete Workflow Guide

### For IMAGE-TO-TEXT (OCR) - Extract text from images

#### Step 1: Select the Model
1. Click on the **"🖼️ Image to Text (OCR)"** card at the top
2. The card will get a **green border** showing it's selected
3. A success message will appear
4. The main button will change to **"🖼️ Extract Text from Image"**

#### Step 2: Select Your Image
1. Click the **"📁 Browse Image"** button
2. Navigate to your image file
3. Select an image (PNG, JPG, JPEG, BMP, or GIF)
4. The file path will appear in the input box
5. A confirmation message shows the image is loaded

#### Step 3: Extract the Text
1. Click the big **"🖼️ Extract Text from Image"** button
2. Wait for processing (you'll see a loading message)
3. The extracted text will appear in the output box
4. Success message confirms completion

**Example:**
- Select image: `handwritten_note.jpg`
- Click "Extract Text from Image"
- Get output: "Hello World, This is a test"

---

### For TEXT-TO-IMAGE - Generate images from descriptions

#### Step 1: Select the Model
1. Click on the **"🎨 Text to Image"** card at the top
2. The card will get a **green border** showing it's selected
3. A success message will appear
4. The main button will change to **"🎨 Generate Image from Text"**

#### Step 2: Enter Your Description
1. Click in the **text input area** (the large text box)
2. Type your image description
3. Be specific and descriptive

**Good Examples:**
- "A cute robot reading a book in a cozy library"
- "Abstract geometric pattern in blue and gold"
- "A serene lake surrounded by pine trees at dawn"
- "Photorealistic portrait of a smiling cat wearing a crown"

**Tips for Better Results:**
- Include style: "photorealistic", "cartoon", "artistic", "3D render"
- Mention colors: "vibrant", "pastel", "monochrome"
- Describe mood: "peaceful", "energetic", "mysterious"
- Add details: lighting, time of day, setting

#### Step 3: Generate the Image
1. Click the big **"🎨 Generate Image from Text"** button
2. Wait 10-30 seconds (image generation takes time!)
3. You'll see a processing message with your prompt
4. When done, the output shows success and file location
5. Image is saved as `output_image.png` in the current folder

**Example:**
- Enter text: "A futuristic city with flying cars at sunset"
- Click "Generate Image from Text"
- Wait for generation
- Open `output_image.png` to see your creation!

---

## 🎯 Quick Tips

### Input Section
- **Large text box**: Enter your text descriptions here for Text-to-Image
- **Browse button**: Click this to select images for Image-to-Text
- Clear instructions show what to do based on your model

### Main Action Button
- **Disabled (gray)**: No model selected yet
- **Green**: Image-to-Text model selected
- **Orange**: Text-to-Image model selected
- **Always shows**: What will happen when you click it

### Output Section
- Shows real-time status (⏳ Processing, ✅ Success, ❌ Error)
- For OCR: Displays extracted text with formatting
- For Image Gen: Shows file info and location
- Use **"🗑️ Clear Output"** to reset

---

## ⚠️ Common Issues & Solutions

### "Please select a model first"
**Problem**: You tried to run without selecting a model  
**Solution**: Click on one of the two model cards at the top

### "Please browse and select an image file first"
**Problem**: Trying to run Image-to-Text without an image  
**Solution**: Click "📁 Browse Image" and select a file

### "Please enter a text description first"
**Problem**: Trying to run Text-to-Image with empty text  
**Solution**: Type a description in the text input box

### "Wrong Input Type"
**Problem**: Using image file for Text-to-Image or vice versa  
**Solution**: 
- For Image-to-Text: Use "Browse Image" button
- For Text-to-Image: Type text in the input box

### Image generation takes too long
**Normal**: Image generation can take 10-30 seconds  
**Solution**: Be patient! The AI is creating a unique image for you

### "File not found" error
**Problem**: The selected image file was moved or deleted  
**Solution**: Browse and select the image again

### "Network error" or "API error"
**Causes**:
- No internet connection
- Hugging Face API is down
- Rate limits reached
- Invalid API token

**Solutions**:
- Check your internet connection
- Wait a few minutes and try again
- Set up HF_TOKEN environment variable if needed

---

## 📝 Complete Example Workflows

### Example 1: Extract Text from Handwritten Note

```
1. Launch: python main.py
2. Click: "🖼️ Image to Text (OCR)" card
3. Click: "📁 Browse Image" button
4. Select: my_handwritten_note.jpg
5. Click: "🖼️ Extract Text from Image" button
6. Wait: ~5 seconds
7. Result: "Dear John, Thank you for your help..."
```

### Example 2: Generate Artwork

```
1. Launch: python main.py
2. Click: "🎨 Text to Image" card
3. Type: "A mystical forest with glowing mushrooms at night"
4. Click: "🎨 Generate Image from Text" button
5. Wait: ~20 seconds
6. Result: Image saved as output_image.png
7. Open: output_image.png to view your creation
```

### Example 3: Switch Between Models

```
1. Start with: Image-to-Text selected
2. Process: an image
3. Switch: Click "🎨 Text to Image" card
4. Notice: Button changes to orange
5. Enter: new text prompt
6. Generate: new image
7. Switch back: Click "🖼️ Image to Text (OCR)" card
8. Button: changes back to green
```

---

## 🎨 Visual Workflow

```
┌─────────────────────────────────────────────────────────┐
│                   SELECT A MODEL                        │
│  [🖼️ Image to Text]  ←  [🎨 Text to Image]           │
│    (Click to select)      (Click to select)            │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                  PROVIDE YOUR INPUT                      │
│  • For OCR: Click "📁 Browse Image"                     │
│  • For Gen: Type text description                       │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                  CLICK ACTION BUTTON                     │
│  [🖼️ Extract Text] or [🎨 Generate Image]              │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                   WAIT & VIEW RESULT                     │
│  • Processing message appears                           │
│  • Result shows in output box                           │
│  • Success message confirms completion                  │
└─────────────────────────────────────────────────────────┘
```

---

## 🎓 For Learning

To understand how the application works:
1. Click **"📚 View OOP Concepts"** in the header
2. Read about Classes, Inheritance, Encapsulation, etc.
3. Each concept has code examples from this project
4. See README.md for technical documentation

---

## ✨ Pro Tips

1. **Save Your Images**: Rename output_image.png after each generation to keep multiple results
2. **Experiment**: Try different description styles to see what works best
3. **Be Specific**: More detailed prompts often produce better images
4. **Clear Between Uses**: Use "🗑️ Clear Output" to reset before new operations
5. **Watch the Button**: The action button color tells you which model is active
6. **Read Messages**: Pop-up messages guide you through each step

---

**You're all set!** Start creating and exploring with AI! 🚀
