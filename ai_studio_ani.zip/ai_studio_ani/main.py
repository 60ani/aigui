from gui import AppGUI

if __name__ == "__main__":
    app = AppGUI()
    app.run()