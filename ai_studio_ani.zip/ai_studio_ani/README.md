# AI Studio - Hugging Face Model Interface

## 🎯 Overview

AI Studio is a modern, enhanced GUI application for interacting with Hugging Face AI models. Built with Tkinter and Python, this application demonstrates advanced Object-Oriented Programming (OOP) principles while providing a user-friendly interface for AI model interaction.

## ✨ Features

### Core Functionality
- **Image to Text (OCR)**: Extract text from handwritten images using Microsoft's TrOCR model
- **Text to Image Generation**: Generate images from text descriptions using FLUX.1-dev model
- **Model Selection**: Easy card-based model selection interface
- **File Management**: Browse and load image files with support for multiple formats

### Enhanced UI/UX
- **Modern Design**: Professional blue color scheme with comfortable contrast
- **Card-Based Layout**: Intuitive model selection with visual cards
- **Visual Feedback**: Color-coded buttons and highlighted selections
- **Responsive Design**: Clean, organized layout with proper spacing
- **Emoji Icons**: Enhanced visual communication throughout the interface

### Educational Component
- **Dedicated OOP Explanation Window**: Comprehensive bachelor's-level explanations of OOP concepts
- **Code References**: Direct links to implementation examples
- **Detailed Concepts Coverage**:
  - Classes and Objects
  - Inheritance
  - Encapsulation
  - Polymorphism & Method Overriding
  - Decorators
  - Modularization
  - Abstraction

## 🎨 Design Enhancements (Version 2.0)

### Color Scheme
- **Primary Blue**: `#2c5aa0` - Professional, trust-inspiring
- **Secondary Blue**: `#4299e1` - Interactive elements
- **Success Green**: `#48bb78` - Positive actions
- **Warning Orange**: `#ed8936` - Attention-requiring actions
- **Danger Red**: `#e53e3e` - Destructive actions
- **Neutral Grays**: Various shades for backgrounds and text

### UI Improvements
1. **Header Section**: Eye-catching header with app title and quick access to OOP concepts
2. **Model Selection Cards**: Visual cards with descriptions and easy selection
3. **Input Configuration**: Clean input section with radio buttons and file browser
4. **Output Display**: Formatted output area with scrolling capability
5. **Action Buttons**: Color-coded buttons for different operations
6. **Model Information**: Dedicated section showing active model details

## 🏗️ Architecture

### Project Structure
```
aigui/
├── main.py              # Application entry point
├── gui.py              # GUI implementation (AppGUI, OOPExplanationWindow)
├── models.py           # AI model classes (BaseModel, ImageToTextModel, TextToImageModel)
├── decorators.py       # Decorator functions (@log_call, @validate_input)
├── explanations.py     # OOP concept explanations
├── requirements.txt    # Project dependencies
└── README.md          # This file
```

### OOP Principles Demonstrated

#### 1. Classes and Objects
- Multiple class definitions (AppGUI, BaseModel, ImageToTextModel, etc.)
- Object instantiation and management

#### 2. Inheritance
```python
class BaseModel:
    # Base functionality
    
class ImageToTextModel(BaseModel):
    # Inherits from BaseModel
    
class TextToImageModel(BaseModel):
    # Inherits from BaseModel
```

#### 3. Encapsulation
- Private attributes with `_` prefix
- Protected methods and data hiding
- API key protection

#### 4. Polymorphism
- Same interface (`run()` method) for different model types
- Dynamic method dispatch based on object type

#### 5. Decorators
- `@log_call` for logging
- `@validate_input` for input validation
- Demonstrates aspect-oriented programming

#### 6. Modularization
- Separation of concerns across multiple files
- Single Responsibility Principle
- Easy maintenance and testing

## 🚀 Getting Started

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd aigui
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up Hugging Face API token (optional but recommended):
```bash
# Windows PowerShell
$env:HF_TOKEN="your_token_here"

# Windows CMD
set HF_TOKEN=your_token_here

# Linux/Mac
export HF_TOKEN=your_token_here
```

### Running the Application

```bash
python main.py
```

## 📖 Usage Guide

### Using Image-to-Text (OCR)
1. Click the **"Image to Text (OCR)"** card to select the model
2. Choose **"Image Input"** radio button
3. Click **"Browse Image"** to select an image file
4. Click **"▶️ Run Image-to-Text"** button
5. View extracted text in the output area

### Using Text-to-Image
1. Click the **"Text to Image"** card to select the model
2. Choose **"Text Input"** radio button
3. Enter your text description in the input field
4. Click **"▶️ Run Text-to-Image"** button
5. Generated image will be saved as `output_image.png`

### Viewing OOP Explanations
- Click **"📚 View OOP Concepts"** button in the header, OR
- Go to **Help → OOP Concepts** in the menu bar
- Read comprehensive explanations with code examples
- Close the window when finished

## 🔧 Technical Details

### Dependencies
- **tkinter**: GUI framework (included with Python)
- **Pillow (PIL)**: Image processing
- **transformers**: Hugging Face transformers library
- **huggingface_hub**: Hugging Face API client

### Supported Models
- **TrOCR** (microsoft/trocr-base-handwritten): Optical Character Recognition
- **FLUX.1-dev** (black-forest-labs/FLUX.1-dev): Text-to-Image generation

### Supported Image Formats
- PNG (.png)
- JPEG (.jpg, .jpeg)
- BMP (.bmp)
- GIF (.gif)

## 🎓 Educational Value

This project serves as an excellent learning resource for:
- **Python Programming**: Intermediate to advanced concepts
- **GUI Development**: Tkinter framework usage
- **OOP Design**: Real-world application of OOP principles
- **API Integration**: Working with external AI services
- **Code Organization**: Project structure and modularization

## 📝 Assignment Requirements Met

✅ **Multiple Inheritance**: BaseModel as parent class  
✅ **Encapsulation**: Private attributes and methods  
✅ **Multiple Decorators**: @log_call, @validate_input  
✅ **Polymorphism**: Overridden run() methods  
✅ **Modularization**: Separate files for different concerns  
✅ **GUI Integration**: Tkinter-based interface  
✅ **AI Model Integration**: Hugging Face models  
✅ **Documentation**: Comprehensive explanations  

## 🆕 Version 2.0 Updates

### UI Enhancements
- Completely redesigned interface with modern aesthetics
- Professional color scheme (blues, greens, grays)
- Card-based model selection
- Enhanced visual hierarchy
- Improved spacing and padding

### UX Improvements
- Better error handling and user feedback
- Loading indicators for model operations
- Success/error messages with icons
- Intuitive navigation

### Documentation
- Dedicated OOP explanation window
- Bachelor's-level detailed explanations
- Code examples and references
- Formatted, scrollable content

## 🤝 Contributing

This is an educational project. For improvements:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

This project is created for educational purposes as part of HIT137 coursework.

## 👥 Authors

- Group Assignment 3 Team
- HIT 137 - Charles Darwin University

## 🙏 Acknowledgments

- Hugging Face for AI model APIs
- Microsoft for TrOCR model
- Black Forest Labs for FLUX.1-dev model
- Python community for excellent libraries

---

**Note**: This application requires an internet connection to access Hugging Face models. Processing times may vary based on network speed and model complexity.
```